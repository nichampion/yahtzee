#ifndef affichage_h
#define affichage_h

  void affichage(t_joueur *j1, t_joueur *j2, t_joueur *jc);

#endif
